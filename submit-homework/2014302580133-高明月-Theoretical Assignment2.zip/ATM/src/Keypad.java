import java.util.Scanner; // program uses Scanner to obtain user input
public class Keypad
 {
 private Scanner input; 
 public int num;// reads data from the command line
// no-argument constructor initializes the Scanner
 public boolean b=false;
 public Keypad()
 {
 } // end no-argument Keypad constructor

 // return an integer value entered by user
 public int getInput()
 {   b=false;
	 while(!b){System.out.print("");}
 return num; // we assume that user enters an integer
 } // end method getInput
 }