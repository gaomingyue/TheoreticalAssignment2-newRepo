import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import java.io.PrintStream;
import java.awt.AWTException;
import java.io.IOException;
import javax.swing.UIManager;


public class MyFrame extends JFrame {

	private JPanel contentPane;
	private JTextArea textarea;
	private JTextField textField1;
	private JTextField textField2;
	private PrintStream printstream;
	private JScrollPane jscrollpane;
	String input;
	public ATM atm;

	

	/**
	 * Create the frame.
	 */
	public MyFrame() {
		setBackground(Color.RED);
		/*MyFrame myframe = new MyFrame();
		myframe.setVisible(true);
		setTitle("ATM");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 493, 389);*/
		
		contentPane = new JPanel();
		contentPane.setBackground(UIManager.getColor("MenuBar.background"));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		
		jscrollpane = new JScrollPane();
		jscrollpane.setBounds(10, 10, 420, 140);
		contentPane.add(jscrollpane);
		
		textarea = new JTextArea();
		textarea.setBackground(UIManager.getColor("Menu.selectionBackground"));
		jscrollpane.setViewportView(textarea);
		textarea.setEditable(false);
		
		printstream=new PrintStream(System.out)
				{
			  public void print(String x){
				  textarea.append(x);
				  textarea.setCaretPosition( textarea.getText().length());}
				};
				 System.setOut(printstream);
		
		JButton btnNewButton_1 = new JButton("2");
		btnNewButton_1.setBackground(UIManager.getColor("MenuItem.selectionBackground"));
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				input="2";
				input=input+"2";
				 textarea.append("2");
			}
		});
		btnNewButton_1.setBounds(60, 158, 50, 50);
		contentPane.add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("3");
		btnNewButton_2.setBackground(UIManager.getColor("MenuItem.selectionBackground"));
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
					input="3";
					input=input+"3";
				textarea.append("3");
			}
		});
		btnNewButton_2.setBounds(110, 158, 50, 50);
		contentPane.add(btnNewButton_2);
		
		JButton btnNewButton_3 = new JButton("4");
		btnNewButton_3.setBackground(UIManager.getColor("MenuItem.selectionBackground"));
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				input="4";
				input=input+"4";
				textarea.append("4");
			}
		});
		btnNewButton_3.setBounds(10, 208, 50, 50);
		contentPane.add(btnNewButton_3);
		
		JButton btnNewButton_4 = new JButton("5");
		btnNewButton_4.setBackground(UIManager.getColor("MenuItem.selectionBackground"));
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				input="5";
				input=input+"5";
				textarea.append("5");
			}
		});
		btnNewButton_4.setBounds(60, 208, 50, 50);
		contentPane.add(btnNewButton_4);
		
		JButton btnNewButton_5 = new JButton("6");
		btnNewButton_5.setBackground(UIManager.getColor("MenuItem.selectionBackground"));
		btnNewButton_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				input="6";
				input=input+"6";
				textarea.append("6");
			}
		});
		btnNewButton_5.setBounds(110, 208, 50, 50);
		contentPane.add(btnNewButton_5);
		
		JButton btnNewButton_6 = new JButton("7");
		btnNewButton_6.setBackground(UIManager.getColor("MenuItem.selectionBackground"));
		btnNewButton_6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				input="7";
				input=input+"7";
				textarea.append("7");
			}
		});
		btnNewButton_6.setBounds(10, 258, 50, 50);
		contentPane.add(btnNewButton_6);
		
		JButton btnNewButton_7 = new JButton("8");
		btnNewButton_7.setBackground(UIManager.getColor("MenuItem.selectionBackground"));
		btnNewButton_7.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				input="8";
				input=input+"8";
				textarea.append("8");
			}
		});
		btnNewButton_7.setBounds(60, 258, 50, 50);
		contentPane.add(btnNewButton_7);
		
		JButton btnNewButton_8 = new JButton("9");
		btnNewButton_8.setBackground(UIManager.getColor("MenuItem.selectionBackground"));
		btnNewButton_8.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				input="9";
				input=input+"9";
				textarea.append("9");
			}
		});
		btnNewButton_8.setBounds(110, 258, 50, 50);
		contentPane.add(btnNewButton_8);
		
		JButton btnNewButton_9 = new JButton("0");
		btnNewButton_9.setBackground(UIManager.getColor("MenuItem.selectionBackground"));
		btnNewButton_9.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				input="0";
				input=input+"0";
				textarea.append("0");
			}
		});
		btnNewButton_9.setBounds(10, 308, 50, 50);
		contentPane.add(btnNewButton_9);
		
		atm=new ATM();
		JButton btnNewButton_10 = new JButton("enter");
		btnNewButton_10.setBackground(UIManager.getColor("MenuItem.selectionBackground"));
		btnNewButton_10.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {	
				atm.keypad.num=Integer.parseInt(input);
				atm.keypad.b=true;
				input="";
			
			}
		});
		
	   
		JButton btnNewButton = new JButton("1");
		btnNewButton.setBackground(UIManager.getColor("MenuItem.selectionBackground"));
		btnNewButton.setBounds(10, 158, 50, 50);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				input="1";
				input=input+"1";
				 textarea.append("1");
			}
		});
		contentPane.add(btnNewButton);
		btnNewButton_10.setBounds(60, 308, 100, 50);
		contentPane.add(btnNewButton_10);
		
		JLabel lblNewLabel = new JLabel("Take cash here");
		lblNewLabel.setBounds(250, 144, 90, 40);
		contentPane.add(lblNewLabel);
		
		textField1 = new JTextField();
		textField1.setBackground(UIManager.getColor("Menu.selectionBackground"));
		textField1.setBounds(180, 177, 229, 65);
		contentPane.add(textField1);
		textField1.setColumns(10);
		
		JLabel lblInsertDepo = new JLabel("Insert deposit envelope here");
		lblInsertDepo.setForeground(new Color(0, 0, 0));
		lblInsertDepo.setBounds(208, 252, 168, 15);
		contentPane.add(lblInsertDepo);
		
		textField2 = new JTextField();
		textField2.setBackground(UIManager.getColor("Menu.selectionBackground"));
		textField2.setBounds(180, 274, 229, 65);
		contentPane.add(textField2);
		textField2.setColumns(10);
		
	}
	public static void main(String[] args) throws AWTException, IOException {
		MyFrame myframe = new MyFrame();
		myframe.setVisible(true);
		myframe.setTitle("ATM");
		myframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		myframe.setBounds(100, 100, 493, 389);
		myframe.atm.run();
}
}
